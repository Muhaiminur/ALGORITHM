package cse221lab02;

public class CSE221Lab02 {

    static int[] list = {15, 16, 17, 18, 19, 20, 21, 22, 23, 24};
    static int[] temp = new int[list.length];

    public static void main(String[] args) {
        mergeSort();
        for (int i = 0; i < list.length; i++) {
            System.out.print(list[i] + "==");
        }
    }

    static void mergeSort() {
        divide(0, list.length - 1);
    }

    static void divide(int start, int end) {
        if (start < end) {
            int middle = start + (end - start) / 2;
            divide(start, middle);
            divide(middle + 1, end);
            merge(start, middle, end);
        }

    }

    static void merge(int start, int middle, int end) {
        
        for (int i = start; i <= end; i++) {
            temp[i] = list[i];
        }
        int i = start;
        int j = middle + 1;
        int k = start;

        while (i <= middle && j <= end) {
            if (temp[i] <= temp[j]) {
                list[k] = temp[i];
                i++;
            } else {
                list[k] = temp[j];
                j++;
            }
            k++;
        }
        
        while (i <= middle) {
            list[k] = temp[i];
            k++;
            i++;
        }
        
        while (j <= end) {
            list[k] = temp[j];
            k++;
            j++;
        }
    }
}
