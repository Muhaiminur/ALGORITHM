package cse221lab01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class CSE221Lab01v2 {

    static HashMap<Integer, ArrayList> map = new HashMap<Integer, ArrayList>();
    static String searchResult = "";

    public static void main(String args[]) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\list.txt"));
        String line = null;
        Scanner m = new Scanner(System.in);

        while ((line = reader.readLine()) != null) {
            insertIntoArray(line);
        }
        BufferedReader inputReader = new BufferedReader(new FileReader("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\input.txt"));
        String input = null;

        while ((input = inputReader.readLine()) != null) {
            if (searchResult.equals("")) {
                searchResult = search(input);
            } else {
                searchResult = searchResult + ":" + search(input);
            }
        }
        
        BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\output.txt"));
        searchResult = "<" + searchResult + ">";
        writer.write(searchResult);
        writer.close();
        System.out.println(searchResult+" v2");
    }

    static boolean insertIntoArray(String elem) {
        int len = elem.length();
        boolean exist = searchForArray(len);
        if (exist) {
            ArrayList array = getArrayList(len);
            array.add(elem);
            return true;
        } else {
            ArrayList array = createArrayList(len);
            array.add(elem);
            return true;
        }
    }

    static boolean searchForArray(int len) {
        return map.get(len) != null;
    }

    static ArrayList getArrayList(int key) {
        ArrayList array = map.get(key);
        return array;
    }

    static ArrayList createArrayList(int key) {
        ArrayList<String> array = new ArrayList<String>();
        map.put(key, array);
        return map.get(key);
    }

    private static String search(String searchFor) {
        String result = " ";
        searchFor = searchFor.toLowerCase();
        ArrayList<Integer> input = new ArrayList<Integer>();
        int len = searchFor.length();

        for (int i = 0; i < searchFor.length(); i++) {
            if (searchFor.charAt(i) != '*') {
                input.add(i);
            }
        }
        int k = 0;
        ArrayList<String> array = map.get(len);
        for (String str : array) {
            str = str.toLowerCase();
            for (int i = 0; i < input.size(); i++) {
                if (searchFor.charAt(input.get(i)) == str.charAt(input.get(i))) {
                    k++;
                }
            }
            if (k == input.size()) {
                if (!result.equals(" ")) {
                    result = result + "," + str;
                } else {
                    result = str;
                }
            }
            k = 0;
        }
        return result;
    }
}
