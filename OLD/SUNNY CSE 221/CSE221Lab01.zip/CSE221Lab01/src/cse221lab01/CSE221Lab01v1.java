package cse221lab01;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CSE221Lab01v1 {

    static String searchResult = "";
    static ArrayList<String> array = new ArrayList<String>();

    public static void main(String args[]) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\list.txt"));
        String line = null;
        Scanner m = new Scanner(System.in);

        while ((line = reader.readLine()) != null) {
            array.add(line);
        }
        BufferedReader inputReader = new BufferedReader(new FileReader("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\input.txt"));
        String input = null;

        while ((input = inputReader.readLine()) != null) {
            if (searchResult.equals("")) {
                searchResult = search(input);
            } else {
                searchResult = searchResult + ":" + search(input);
            }
        }

        BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\SunNy\\Documents\\NetBeansProjects\\CSE221Lab01\\src\\cse221lab01\\output.txt"));
        searchResult = "<" + searchResult + ">";
        writer.write(searchResult);
        writer.close();
        System.out.println(searchResult+"v1");
    }

    static String search(String searchFor) {
        String result = " ";
        searchFor = searchFor.toLowerCase();
        ArrayList<Integer> input = new ArrayList<Integer>();
        int len = searchFor.length();

        for (int i = 0; i < searchFor.length(); i++) {
            if (searchFor.charAt(i) != '*') {
                input.add(i);
            }
        }
        int k = 0;
        for (String str : array) {
            if (str.length() == len) {
                str = str.toLowerCase();
                for (int i = 0; i < input.size(); i++) {
                    if (searchFor.charAt(input.get(i)) == str.charAt(input.get(i))) {
                        k++;
                    }
                }
                if (k == input.size()) {
                    if (!result.equals(" ")) {
                        result = result + "," + str;
                    } else {
                        result = str;
                    }
                }
                k = 0;
            }
        }
        return result;
    }
}
